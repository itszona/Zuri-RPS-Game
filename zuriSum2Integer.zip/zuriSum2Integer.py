first_number = 2
second_number = 4
total = first_number + second_number
print(total)